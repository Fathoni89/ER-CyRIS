"""Selected constructed routing checks; values are supplied, not independently verified."""
VERSION = '0.3.0'

def m4(candidate, source_ok, critical_missing, margin, explanation, completeness, tau_d=.5, tau_x=.7, tau_q=.95):
    if candidate is False: return {'status':'no_alert', 'reasons':['BELOW_DETECTOR_THRESHOLD']}
    if candidate is not True: raise ValueError('candidate unavailable')
    reasons=[]
    if not source_ok: reasons.append('SOURCE_UNVERIFIED')
    if critical_missing: reasons.append('CRITICAL_FIELD_MISSING')
    if completeness is None: reasons.append('COMPLETENESS_UNAVAILABLE')
    if reasons: return {'status':'abstain','reasons':reasons}
    d=margin>=tau_d; x=explanation is not None and explanation>=tau_x; q=completeness>=tau_q
    if not d: reasons.append('MARGIN_BELOW_THRESHOLD')
    if explanation is None: reasons.append('EXPLANATION_UNAVAILABLE')
    elif not x: reasons.append('EXPLANATION_BELOW_THRESHOLD')
    if not q: reasons.append('COMPLETENESS_BELOW_THRESHOLD')
    return {'status':'abstain' if not d and not x else 'accept' if d and x and q else 'warn', 'reasons':reasons}

def handoff(m4_status, policy, missing, matches=None, m4_reason=None):
    if m4_status=='no_alert': return {'status':'no_alert','reasons':[], 'actionable':False}
    if m4_status in ('warn','abstain'): return {'status':'ESCALATE_FOR_REVIEW','reasons':[m4_reason], 'actionable':False}
    if m4_status!='accept': raise ValueError('unknown M4 status')
    reasons=list(missing)
    if policy!='valid':
        return {'status':'ESCALATE_FOR_REVIEW','reasons':['RISK_POLICY_'+policy.upper()]+reasons,'actionable':False}
    if reasons: return {'status':'REQUEST_MORE_EVIDENCE','reasons':reasons,'actionable':False}
    if not isinstance(matches,int) or isinstance(matches,bool) or matches<0: raise ValueError('match count required')
    if matches==0:return {'status':'ESCALATE_FOR_REVIEW','reasons':['NO_PLAYBOOK_MATCH'],'actionable':False}
    if matches>1:return {'status':'POLICY_CONFLICT','reasons':['MULTIPLE_PLAYBOOK_MATCHES'],'actionable':False}
    return {'status':'RECOMMENDATION_AVAILABLE','reasons':['UNIQUE_PLAYBOOK_MATCH_ASSUMED'],'actionable':True}

def authorize(actionable, permission, approval, prior_reason=None):
    if not actionable: return {'status':'NO_ACTIONABLE_RECOMMENDATION','reasons':[prior_reason], 'actual_action':None}
    if permission not in ('denied','allowed','unknown') or approval not in ('granted','pending','unknown'): raise ValueError('invalid supplied state')
    reasons=[]
    if permission=='denied': reasons.append('ROLE_OR_ACTION_NOT_PERMITTED')
    if permission=='unknown': reasons.append('PERMISSION_UNAVAILABLE')
    if approval=='unknown': reasons.append('APPROVAL_UNAVAILABLE')
    if approval=='pending': reasons.append('APPROVAL_NOT_GRANTED')
    if permission=='denied': status='AUTHORIZATION_BLOCKED'
    elif permission=='unknown' or approval=='unknown': status='AUTHORIZATION_UNAVAILABLE'
    elif approval=='pending': status='PENDING_AUTHORIZATION'
    else: status='AUTHORIZED_FOR_HUMAN_EXECUTION'
    return {'status':status,'reasons':reasons,'actual_action':None}
