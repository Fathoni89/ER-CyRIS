#!/usr/bin/env python3
"""python audit_cakupan.py  -- membaca arsip asli, menulis hasil audit terpisah."""
import csv,hashlib,json,sys,platform
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
import rules_original as rules
root=Path(__file__).resolve().parent
cases=json.loads((root/'cases_original.json').read_text()); old=json.loads((root/'results_original.json').read_text())
assert len(cases)==31 and len(old['results'])==31
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'rules_original.py')==old['hashes']['rules.py']
assert sha(root/'cases_original.json')==old['hashes']['cases.json']
stored={r['id']:r for r in old['results']}; assert len(stored)==31
results=[]
for c in cases:
 fn=getattr(rules,c['function']); actual=fn(**c['input']); rec=stored[c['id']]
 assert rec['input']==c['input'] and rec['expected']==c['expected']
 results.append({'id':c['id'],'function':c['function'],'expected':c['expected'],'archived_actual':rec['actual'],'rerun_actual':actual,'archived_match':rec['actual']==c['expected'],'rerun_match':actual==c['expected'],'unchanged_from_archived':actual==rec['actual']})
assert all(r['archived_match'] and r['rerun_match'] and r['unchanged_from_archived'] for r in results)
m4=[c for c in cases if c['function']=='m4'];assert len(m4)==14
dup=defaultdict(list)
for c in m4:dup[json.dumps(c['input'],sort_keys=True)].append(c['id'])
def priority(c):
 x=c['input'];a=x['candidate'];h=(not x['source_ok']) or x['critical_missing'] or x['completeness'] is None
 if a is False:return 1
 if h:return 2
 D=x['margin']>=.5;X=x['explanation'] is not None and x['explanation']>=.7;Q=x['source_ok'] and x['completeness']>=.95
 if not D and not X:return 3
 if D and X and Q:return 4
 return 5
coverage={str(i):[c['id'] for c in m4 if priority(c)==i] for i in range(1,6)}
extras=[
 {'id':'M4-BARU-01','description':'Nilai kelengkapan tidak tersedia pada kandidat; semua kondisi lain valid','input':{'candidate':True,'source_ok':True,'critical_missing':False,'margin':.8,'explanation':.85,'completeness':None},'expected':{'status':'abstain','reasons':['COMPLETENESS_UNAVAILABLE']}},
 {'id':'M4-BARU-02','description':'Non-kandidat diprioritaskan meskipun nilai kelengkapan tidak tersedia','input':{'candidate':False,'source_ok':True,'critical_missing':False,'margin':.8,'explanation':.85,'completeness':None},'expected':{'status':'no_alert','reasons':['BELOW_DETECTOR_THRESHOLD']}},
 {'id':'M4-BARU-03','description':'Sumber tidak terverifikasi dan field kritis hilang secara bersamaan','input':{'candidate':True,'source_ok':False,'critical_missing':True,'margin':.8,'explanation':.85,'completeness':1.0},'expected':{'status':'abstain','reasons':['SOURCE_UNVERIFIED','CRITICAL_FIELD_MISSING']}},
 {'id':'M4-BARU-04','description':'Sumber tidak terverifikasi dan nilai kelengkapan tidak tersedia','input':{'candidate':True,'source_ok':False,'critical_missing':False,'margin':.8,'explanation':.85,'completeness':None},'expected':{'status':'abstain','reasons':['SOURCE_UNVERIFIED','COMPLETENESS_UNAVAILABLE']}}
]
for x in extras:
 x['actual']=rules.m4(**x['input']);x['match']=x['expected']==x['actual']
assert all(x['match'] for x in extras)
out={'executed_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'paper_snapshot_sha256':'1a18d7f908129453882e346f370ca3ceea41d3448358eb979416d97cb9fae96c','source_hashes':{'rules_original.py':sha(root/'rules_original.py'),'cases_original.json':sha(root/'cases_original.json'),'results_original.json':sha(root/'results_original.json')},'archived_entries':31,'rerun_match_count':sum(r['rerun_match'] for r in results),'by_function':dict(Counter(r['function'] for r in results)),'m4_entries':14,'m4_unique_inputs':len(dup),'duplicates':[v for v in dup.values() if len(v)>1],'priority_coverage':coverage,'extra_cases':extras,'full_rerun':results,'limitations':['Case coverage mapping based on known supplied valid states and paper Table 4 from specified snapshot; paper may have been edited later.','Source, candidate, explanation and completeness are supplied; no raw log, model, actual source verification or SHAP is exercised.','Feature-list absence cannot be directly represented as separate input; completeness=None is one representative unavailable value.','Status and reasons agree on illustrative cases; cases and code derive from same specification, no independence or operational effectiveness claim.','Does not test all input domains, malformed data or end-to-end M1-M6.']}
(root/'hasil_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (root/'hasil_ringkas.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['id','jenis','expected_status','actual_status','alasan_actual','sesuai'])
 for r in results:w.writerow([r['id'],'arsip',r['expected']['status'],r['rerun_actual']['status'],';'.join(map(str,r['rerun_actual'].get('reasons',[]))),r['rerun_match']])
 for r in extras:w.writerow([r['id'],'tambahan',r['expected']['status'],r['actual']['status'],';'.join(r['actual']['reasons']),r['match']])
print(json.dumps({'archived_rerun':f"{out['rerun_match_count']}/31",'m4_cases':len(m4),'unique_m4_inputs':len(dup),'duplicates':out['duplicates'],'priorities':coverage,'added':f"{sum(x['match'] for x in extras)}/{len(extras)}"},indent=2))
