import csv,datetime,hashlib,json,platform,sys
from pathlib import Path
import ercyris_contract as impl
p=Path(__file__).parent;cases=json.loads((p/'cases_m5.json').read_text());rows=[]
for case in cases:
 args=dict(case['input'])
 if isinstance(args.get('band_map'),dict):args['band_map']={int(k):v for k,v in args['band_map'].items()}
 try:actual=impl.risk(**args);err=None
 except Exception as e:actual=None;err=type(e).__name__+': '+str(e)
 rows.append({**case,'actual':actual,'match':actual==case['expected'],'error':err})
files=['ercyris_contract.py','cases_m5.json','run_m5.py'];sha=lambda f:hashlib.sha256((p/f).read_bytes()).hexdigest()
result={'purpose':'constructed M5 arithmetic and input-state checks; no independent validation','executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'hashes':{f:sha(f) for f in files},'total':len(rows),'matched':sum(x['match'] for x in rows),'results':rows}
(p/'results_m5.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (p/'results_m5.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['id','purpose','input','expected','actual','match','error']);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})
print(f"M5: {result['matched']}/{result['total']} matched")
if result['matched']!=result['total']:sys.exit(1)
