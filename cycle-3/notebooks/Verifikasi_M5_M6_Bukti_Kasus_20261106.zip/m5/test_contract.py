import unittest
import ercyris_contract as e

class TestM3(unittest.TestCase):
 def test_identical(self):
  a=e.explanation([3.,-1.,0.],[3.,-1.,0.],2); self.assertEqual((a['J'],a['B'],a['S'],a['x']),(1.,1.,1.,1.))
 def test_sign_flipped(self):
  a=e.explanation([2.,1.],[2.,-1.],2); self.assertAlmostEqual(a['B'],2/3); self.assertEqual(a['S'],.5); self.assertAlmostEqual(a['x'],13/18)
 def test_zero_unavailable(self):
  a=e.explanation([0.,0.],[0.,0.],2); self.assertIsNone(a['x']);self.assertEqual(a['status'],'EXPLANATION_UNAVAILABLE')
 def test_no_common_nonzero(self):
  a=e.explanation([1.,0.],[0.,1.],1);self.assertEqual(a['J'],0.);self.assertIsNone(a['S']);self.assertIsNone(a['x'])
 def test_nonfinite_unavailable(self):
  a=e.explanation([float('nan')],[1.],1);self.assertIsNone(a['x']);self.assertEqual(a['status'],'EXPLANATION_UNAVAILABLE')
 def test_ties_index_order(self):
  a=e.explanation([1.,-1.],[1.,1.],1);self.assertEqual(a['J'],1.);self.assertEqual(a['S'],1.)
 def test_sign_ignores_zero_side(self):
  a=e.explanation([1.,2.,0.],[1.,0.,-2.],3);self.assertEqual(a['S'],1.)
 def test_unequal_dimension_rejected(self):
  with self.assertRaises(ValueError):e.explanation([1.,2.],[1.],1)
class TestM4(unittest.TestCase):
 def run_m4(self,**change):
  x={'score':.9,'theta':.2,'source_ok':True,'critical_missing':False,'q':1.,'x':.8,'tau_d':.5,'tau_x':.7,'tau_q':.9};x.update(change);return e.m4(**x)
 def test_invalid_detection(self): self.assertEqual(self.run_m4(score=None)['status'],'DETECTION_UNAVAILABLE')
 def test_no_alert_first(self): self.assertEqual(self.run_m4(score=.1,source_ok=False)['status'],'no_alert')
 def test_critical(self): self.assertEqual(self.run_m4(source_ok=False)['status'],'abstain')
 def test_accept(self): self.assertEqual(self.run_m4()['status'],'accept')
 def test_low_margin_and_missing_x(self):self.assertEqual(self.run_m4(score=.3,x=None)['status'],'abstain')
 def test_high_margin_missing_x(self):
  a=self.run_m4(x=None);self.assertEqual(a['status'],'warn');self.assertIn('EXPLANATION_UNAVAILABLE',a['reasons'])
 def test_q_missing_critical(self):self.assertEqual(self.run_m4(q=None)['status'],'abstain')
 def test_low_q(self):self.assertEqual(self.run_m4(q=.4)['status'],'warn')
class TestM5M6(unittest.TestCase):
 def test_valid_risk(self):
  a=e.risk(m4_status='accept',threat_valid=True,asset_valid=True,scenario_valid=True,likelihood=3,cia=(2,3,4),policy_valid=True,band_map={i:('low' if i<=5 else 'moderate' if i<=10 else 'high' if i<=15 else 'critical') for i in range(1,26)})
  self.assertEqual((a['likelihood'],a['impact'],a['risk'],a['band']),(3,4,12,'high'))
 def test_missing_risk(self):
  a=e.risk(m4_status='accept',threat_valid=True,asset_valid=False,scenario_valid=True,likelihood=3,cia=(2,3,4),policy_valid=True,band_map=None);self.assertIsNone(a['risk'])
 def test_risk_not_invoked_for_warn(self):
  a=e.risk(m4_status='warn',threat_valid=True,asset_valid=True,scenario_valid=True,likelihood=3,cia=(2,3,4),policy_valid=True,band_map={i:'x' for i in range(1,26)});self.assertEqual(a['status'],'NOT_INVOKED');self.assertIsNone(a['risk'])
 def test_policy_first(self):
  a=e.handoff('accept',False,['ASSET_UNAVAILABLE'],None);self.assertEqual(a['status'],'ESCALATE_FOR_REVIEW');self.assertIn('ASSET_UNAVAILABLE',a['reasons'])
 def test_denial_before_unknown(self):
  a=e.authorize(True,'denied','unknown');self.assertEqual(a['status'],'AUTHORIZATION_BLOCKED');self.assertIn('APPROVAL_UNAVAILABLE',a['reasons']);self.assertIsNone(a['actual_action'])
 def test_unknown_approval(self): self.assertEqual(e.authorize(True,'allowed','unknown')['status'],'AUTHORIZATION_UNAVAILABLE')
 def test_pending(self): self.assertEqual(e.authorize(True,'allowed','pending')['status'],'PENDING_AUTHORIZATION')
 def test_authorized_no_action(self): self.assertIsNone(e.authorize(True,'allowed','granted')['actual_action'])
if __name__=='__main__':unittest.main(verbosity=2)
