import json
from pathlib import Path
base={'m4_status':'accept','threat_valid':True,'asset_valid':True,'scenario_valid':True,'likelihood':3,'cia':[2,3,4],'policy_valid':True,'band_map':{str(i):('low' if i<=5 else 'moderate' if i<=10 else 'high' if i<=15 else 'critical') for i in range(1,26)}}
def case(i,desc,change,expected):return {'id':i,'purpose':desc,'input':{**base,**change},'expected':expected}
def missing(*reasons):return {'status':'RISK_NOT_COMPUTABLE','risk':None,'reasons':list(reasons)}
cases=[
case('M5-01','Semua input ilustratif lengkap; dampak maksimum',{}, {'status':'RISK_COMPUTED','likelihood':3,'impact':4,'risk':12,'band':'high','reasons':[]}),
case('M5-02','Batas bawah likelihood dan dampak',{'likelihood':1,'cia':[1,1,1]}, {'status':'RISK_COMPUTED','likelihood':1,'impact':1,'risk':1,'band':'low','reasons':[]}),
case('M5-03','Batas atas likelihood dan dampak',{'likelihood':5,'cia':[5,3,2]}, {'status':'RISK_COMPUTED','likelihood':5,'impact':5,'risk':25,'band':'critical','reasons':[]}),
case('M5-04','Ancaman belum tersedia',{'threat_valid':False},missing('THREAT_UNAVAILABLE')),
case('M5-05','Aset belum tersedia',{'asset_valid':False},missing('ASSET_UNAVAILABLE')),
case('M5-06','Skenario belum tersedia',{'scenario_valid':False},missing('SCENARIO_UNAVAILABLE')),
case('M5-07','Likelihood belum tersedia',{'likelihood':None},missing('LIKELIHOOD_UNAVAILABLE')),
case('M5-08','Salah satu nilai dampak belum tersedia',{'cia':[2,None,4]},missing('IMPACT_UNAVAILABLE')),
case('M5-09','Kebijakan risiko belum tersedia',{'policy_valid':False},missing('RISK_POLICY_UNAVAILABLE')),
case('M5-10','Aset dan kebijakan tidak tersedia bersamaan',{'asset_valid':False,'policy_valid':False},missing('ASSET_UNAVAILABLE','RISK_POLICY_UNAVAILABLE')),
case('M5-11','Tabel kategori risiko belum tersedia',{'band_map':None},missing('RISK_BAND_MAP_UNAVAILABLE')),
case('M5-12','M4 no_alert tidak memanggil M5',{'m4_status':'no_alert'}, {'status':'NOT_INVOKED','risk':None,'reasons':['NO_ALERT']}),
case('M5-13','M4 warn tidak memanggil M5',{'m4_status':'warn'}, {'status':'NOT_INVOKED','risk':None,'reasons':['M4_NOT_ACCEPTED']}),
case('M5-14','M4 abstain tidak memanggil M5',{'m4_status':'abstain'}, {'status':'NOT_INVOKED','risk':None,'reasons':['M4_NOT_ACCEPTED']}),
]
Path('cases_m5.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
