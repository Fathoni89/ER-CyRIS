# Verifikasi terbatas M5 dan handoff M5–M6 ER-CyRIS — 6 November 2026

## Kaitan dengan paper
Acuan tekstual: BEEI_V2_Fathoni(5).docx, §2.5.4–2.5.5, Table 5–6. Rancangan M5 mensyaratkan ancaman, aset, skenario/likelihood, dampak dan kebijakan yang valid, memilih dampak maksimum CIA, dan mengalikan likelihood × dampak. Handoff Table 5 mengutamakan no_alert / warn / abstain, lalu kebijakan risiko dan input yang hilang, lalu jumlah kecocokan playbook. Table 6 memprioritaskan penolakan terverifikasi, kemudian data izin/persetujuan tidak tersedia, persetujuan tertunda, dan persetujuan terverifikasi.

## Asal dan isi kasus
`archive_copy/` adalah SALINAN dari arsip sebelumnya. `results_archived_original.json/.csv` merupakan salinan hasil semula sebelum penjalanan ulang. Paket berisi 31 entri: 14 M4 (termasuk dua entri dengan input dan ekspektasi identik), 9 handoff M5–M6, 8 otorisasi. Kasus dan aturan berasal dari spesifikasi yang sama; bukan 31 insiden atau sampel independen.

`m5/` memakai implementasi acuan yang disalin dari ER_CyRIS_Bab7_Persiapan dan 14 kasus baru yang dirancang khusus untuk menghitung dan memeriksa batas masukan M5. Kasus baru bukan berasal dari log atau pakar. Ekspektasi dibuat sebelum eksekusi dan dicatat dalam cases_m5.json; masukan, hasil yang diharapkan, hasil aktual dan kesesuaiannya tercatat pada results_m5.json/.csv. Peta kategori low/moderate/high/critical dan semua angka bersifat ilustratif, bukan kebijakan UNSAP. Nama alasan/status RISK_NOT_COMPUTABLE dan NOT_INVOKED adalah label teknis acuan; gunakan persis terminologi paper ketika menulis naskah.

## Hasil dan reproduksi
Python 3.10+ tanpa pustaka tambahan. Jalankan `python repeat_checks.py` di folder paket. Setiap runner menimpa hanya hasil di direktori kerja: salin paket sebelum menjalankan ulang. Tiga proses terpisah dalam satu lingkungan menghasilkan 31/31 dan 14/14 kecocokan pada setiap proses, dengan signature keluaran yang sama. 31 hasil cocok dengan salinan hasil arsip sebelumnya. File `summary.json` dan `repeat_1.json` hingga `repeat_3.json` merekam hasil dan hash, sedangkan `m5/unit_tests.txt` memuat 24 tes lama M3/M4/M5/M6; 24 tes tersebut dapat tumpang tindih dengan kasus dan tidak ditambahkan ke jumlah kasus sebagai observasi independen.

## Batas yang harus dipertahankan
- Tiga pengulangan pada satu lingkungan membuktikan repeatability terbatas untuk kasus dan lingkungan tersebut; tidak membuktikan reliabilitas statistik, independensi, kinerja lapangan atau kualitas organisasi.
- Dua implementasi adalah acuan TERPISAH: hasil bukan uji integrasi utuh M1–M6. Handoff dan izin menerima status yang DIPASOK; tidak membuktikan keaslian aset, masa berlaku, aturan konflik scenario, unique lookup skenario, pencocokan playbook riil, keabsahan kebijakan, atau persetujuan sesungguhnya. RISK_COMPUTED hanya ketika flag dianggap valid dalam kasus ilustratif.
- Handoff `m4_reason` dan `prior_reason` menerima satu nilai; tidak dibuktikan end-to-end pelestarian seluruh alasan M4→M5→M6 dalam semua kombinasi. Beberapa input malformed di luar cakupan.
- Tidak memproses log SIUTER, tidak menggunakan penilaian pakar, tidak menghitung risiko resmi UNSAP, dan tidak menjalankan tindakan.
- Semua kasus diturunkan dari spesifikasi yang sama dengan implementasi; bukan penilaian independen akurasi, validitas klinis/organisasional, efektivitas atau generalisasi.
