import datetime,hashlib,json,platform,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent; results={}
for name,folder,runner,outfile in [('routing','archive_copy','run_cases.py','results.json'),('m5','m5','run_m5.py','results_m5.json')]:
 runs=[]
 for n in range(1,4):
  r=subprocess.run([sys.executable,runner],cwd=p/folder,text=True,capture_output=True)
  if r.returncode:raise RuntimeError(name+' run '+str(n)+' failed: '+r.stderr)
  data=json.loads((p/folder/outfile).read_text());(p/folder/('repeat_'+str(n)+'.json')).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
  signature=[{'id':x['id'],'actual':x['actual'],'match':x['match'],'error':x['error']} for x in data['results']]
  runs.append({'run':n,'matched':data['matched'],'total':data['total'],'output_sha256':hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest(),'signature':signature})
 if len({x['output_sha256'] for x in runs})!=1:raise RuntimeError(name+' differs across runs')
 orig=None
 if name=='routing':
  old=json.loads((p/folder/'results_archived_original.json').read_text());orig=[{'id':x['id'],'actual':x['actual'],'match':x['match'],'error':x['error']} for x in old['results']];orig=(orig==runs[0]['signature'])
 results[name]={'runs':[ {k:v for k,v in x.items() if k!='signature'} for x in runs],'same_output_across_runs':True,'same_as_original_archived' :orig}
t=subprocess.run([sys.executable,'-m','unittest','-v','test_contract'],cwd=p/'m5',text=True,capture_output=True)
(p/'m5'/'unit_tests.txt').write_text(t.stdout+t.stderr)
if t.returncode:raise RuntimeError('unit tests failed')
result={'executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'repeatability_scope':'3 separate processes same environment and inputs; not independent statistical reliability','sets':results,'unit_tests_scope':'24 developer checks on M3/M4/M5/M6; overlap with cases possible','unit_tests_exit_code':t.returncode}
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
