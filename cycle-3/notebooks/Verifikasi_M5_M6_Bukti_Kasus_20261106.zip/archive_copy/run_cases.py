import csv,datetime,hashlib,json,platform
from pathlib import Path
import rules
p=Path(__file__).parent
cases=json.loads((p/'cases.json').read_text())
rows=[]
for c in cases:
 try: actual=getattr(rules,c['function'])(**c['input']); error=None
 except Exception as e: actual=None; error=f'{type(e).__name__}: {e}'
 rows.append({**c,'actual':actual,'match':actual==c['expected'],'error':error})
sha=lambda f:hashlib.sha256((p/f).read_bytes()).hexdigest()
result={'version':rules.VERSION,'executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'hashes':{f:sha(f) for f in ['rules.py','cases.json','run_cases.py','make_cases.py','old_cases.json']},'total':len(rows),'matched':sum(r['match'] for r in rows),'results':rows}
(p/'results.json').write_text(json.dumps(result,indent=2)+'\n')
with (p/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','reference','function','input','expected','actual','match','error']);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()})
print(f"{result['matched']}/{result['total']} match")
if result['matched']!=result['total']:raise SystemExit(1)
