# ER-CyRIS reference routing checks v0.3.0

The package checks selected constructed routing conditions against Tables 4–6 in the BEEI manuscript retrieved on 29 October 2026. It is a separate version: it does not overwrite earlier research, UNSW results, or the v0.1.0 22-case archive. The cases and implementation were developed from the same written specification and therefore are not independent empirical validation.

## Contents

* `rules.py`: selected M4, M5-to-M6 handoff, and M6 authorization branches.
* `cases.json`: inputs and expected complete dictionaries. Fourteen M4 cases are inherited from v0.1.0, including M4-03 and M4-05, which duplicate one another. Nine cases examine Table 5 handoffs; eight examine Table 6 authorization. Thus 31 entries do not represent 31 independent incidents.
* `results.json` and `results.csv`: actual output, full expected output, match, errors, runtime and SHA-256 hashes. `audit_22_old_cases.csv` records the comparison of each earlier case against current tables. `old_cases.json` preserves the old input and expected data.
* `make_cases.py` documents case construction. `run_cases.py` compares complete output objects and writes results. `Catatan_Penyelarasan_Paper.docx` provides precise manuscript replacement text.

## Reproduce

Requires Python 3.10 or later; no additional libraries. Unzip into a new directory, retain the original zip, then run `python run_cases.py`. The runner overwrites the extracted results files. `python make_cases.py` can reconstruct cases from the preserved old case file and additional explicitly stated cases; it overwrites `cases.json`.

## Scope and conventions

M4 receives a candidate and precomputed inputs, not raw logs, detector predictions or SHAP. Test thresholds 0.50, 0.70 and 0.95 are illustrative. Table 5 receives supplied policy state, missing-reason list and match count; it neither checks an approved policy nor computes likelihood, impact, risk score or playbook matching. A single match returns an illustrative local status, not actual playbook text. Table 6 assumes supplied `permission` of allowed/denied/unknown reflects available evidence, and `approval` of granted/pending/unknown: denied is verified denial, pending is confirmed not granted, unknown means status cannot be verified. Reasons are retained for simultaneous failures. No recommended action is executed. No-incident and upstream status local labels are clearly marked in output. These narrow supplied-state conventions do not establish handling of every malformed input or all combinations.

The 22-entry comparison is a case audit, not proof of equivalence of every possible input. The original code checks availability before permission and uses approval false as not verified; the revised convention distinguishes confirmed pending from unknown. Existing M4 duplicates and the common origin of cases and code preclude counting results as independent observations or statistical reliability. The package does not validate local explanation fidelity, M5 risk accuracy, real organizational policy, response effectiveness, or the complete M1–M6 chain. Prior independent review and operational evaluation remain required.

## Publication

This zip is a research working artifact, not a verified publicly accessible permanent repository link. Deposit the reviewed package and its dependency files in a reader-accessible archive before claiming public availability. Preserve the existing GitHub materials.

Manuscript source snapshot SHA-256: f9b27c974f6a4c519e4a0eec1b0bc65555281312128bffb372adc0f15aa07882; Drive modified 2026-10-29 00:48:10 UTC. The manuscript itself is not included.
