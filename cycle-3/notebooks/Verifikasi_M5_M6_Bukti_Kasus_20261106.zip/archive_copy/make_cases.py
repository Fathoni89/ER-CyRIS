import json
from pathlib import Path
old=json.loads((Path(__file__).parent/'old_cases.json').read_text())
cases=[]
for c in old:
 if c['method']=='m4': cases.append({'id':c['id'],'reference':'Table 4','function':'m4','input':c['input'],'expected':c['expected']})
def add(id,ref,fn,inputs,status,reasons,**rest):
 cases.append({'id':id,'reference':ref,'function':fn,'input':inputs,'expected':{'status':status,'reasons':reasons,**rest}})
for i,(state,policy,missing,matches,reason,status,reasons,act) in enumerate([
 ('no_alert','valid',[],None,None,'no_alert',[],False),
 ('warn','valid',[],None,'MARGIN_BELOW_THRESHOLD','ESCALATE_FOR_REVIEW',['MARGIN_BELOW_THRESHOLD'],False),
 ('abstain','valid',[],None,'SOURCE_UNVERIFIED','ESCALATE_FOR_REVIEW',['SOURCE_UNVERIFIED'],False),
 ('accept','unavailable',['MISSING_ASSET'],None,None,'ESCALATE_FOR_REVIEW',['RISK_POLICY_UNAVAILABLE','MISSING_ASSET'],False),
 ('accept','invalid',['MISSING_THREAT'],None,None,'ESCALATE_FOR_REVIEW',['RISK_POLICY_INVALID','MISSING_THREAT'],False),
 ('accept','valid',['MISSING_SCENARIO','MISSING_ASSET'],None,None,'REQUEST_MORE_EVIDENCE',['MISSING_SCENARIO','MISSING_ASSET'],False),
 ('accept','valid',[],0,None,'ESCALATE_FOR_REVIEW',['NO_PLAYBOOK_MATCH'],False),
 ('accept','valid',[],2,None,'POLICY_CONFLICT',['MULTIPLE_PLAYBOOK_MATCHES'],False),
 ('accept','valid',[],1,None,'RECOMMENDATION_AVAILABLE',['UNIQUE_PLAYBOOK_MATCH_ASSUMED'],True),
 ],1): add('T5-%02d'%i,'Table 5','handoff',dict(m4_status=state,policy=policy,missing=missing,matches=matches,m4_reason=reason),status,reasons,actionable=act)
for i,(action,perm,approval,prior,status,reasons) in enumerate([
 (False,'unknown','unknown','MISSING_ASSET','NO_ACTIONABLE_RECOMMENDATION',['MISSING_ASSET']),
 (True,'denied','unknown',None,'AUTHORIZATION_BLOCKED',['ROLE_OR_ACTION_NOT_PERMITTED','APPROVAL_UNAVAILABLE']),
 (True,'denied','granted',None,'AUTHORIZATION_BLOCKED',['ROLE_OR_ACTION_NOT_PERMITTED']),
 (True,'unknown','unknown',None,'AUTHORIZATION_UNAVAILABLE',['PERMISSION_UNAVAILABLE','APPROVAL_UNAVAILABLE']),
 (True,'unknown','granted',None,'AUTHORIZATION_UNAVAILABLE',['PERMISSION_UNAVAILABLE']),
 (True,'allowed','unknown',None,'AUTHORIZATION_UNAVAILABLE',['APPROVAL_UNAVAILABLE']),
 (True,'allowed','pending',None,'PENDING_AUTHORIZATION',['APPROVAL_NOT_GRANTED']),
 (True,'allowed','granted',None,'AUTHORIZED_FOR_HUMAN_EXECUTION',[]),
 ],1): add('T6-%02d'%i,'Table 6','authorize',dict(actionable=action,permission=perm,approval=approval,prior_reason=prior),status,reasons,actual_action=None)
Path(__file__).with_name('cases.json').write_text(json.dumps(cases,indent=2)+'\n')
