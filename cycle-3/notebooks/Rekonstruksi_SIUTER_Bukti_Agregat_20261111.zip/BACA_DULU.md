# Rekonstruksi 1.807 catatan non-kandidat SIUTER

## Hasil
Skrip ini membaca file log dan konverter yang hash-nya sama dengan keluaran pilot, serta arsip 46 kandidat yang sudah diekspor. Dalam 38 jendela terjadwal, 1.853 catatan cocok dengan hitungan dan distribusi periode sebelumnya. Semua 46 referensi kandidat (nomor baris, ID dan timestamp) cocok; 1.807 lainnya direkonstruksi sebagai komplemen dari himpunan kandidat yang tersimpan. Distribusinya: INFO 965, DEBUG 836, WARNING 6.

Ini bukan penghitungan ulang model, kalibrator, ambang, SHAP, atau M4. Arsip pilot awal hanya menyimpan agregat; kesamaan agregat dan referensi kasus tidak memastikan masing-masing prediksi run awal. Skor individual 1.807 kasus tidak tersedia pada ekspor ini. Informasi grup non-kandidat merupakan komplemen terhadap daftar kandidat dari arsip. Tidak berarti seluruh kejadian non-kandidat aman atau bukan insiden. Tidak ada acuan/label pakar independen untuk kasus-kasus ini.

## Berkas
- hasil_agregat.json: jumlah, pemeriksaan, hash, batasan.
- rekonstruksi.py: kode yang membaca log dan arsip sumber.
- non_kandidat_1807_RESTRICTED.csv: ID pseudonim, nomor baris pada log yang didekompresi, waktu log, level dan keanggotaan hasil arsip. Simpan terbatas. Nomor baris dan waktu memungkinkan pencocokan ke sumber, sehingga bukan data anonim. Tidak ada teks log, IP, nama pengguna atau nilai skor dalam CSV.

## Reproduksi
Instal dependensi yang dibutuhkan konverter tepercaya, termasuk pandas dan numpy. Jalankan dengan file yang cocok hash:
python rekonstruksi.py --log laravel.log.gz --converter siuter_log_to_dataset.py --kasus kasus_46_RESTRICTED.zip --out hasil

Skrip memvalidasi hash log dan konverter, jumlah tiap jendela, jumlah dan level, 46 referensi kandidat dan keunikan ID sebelum membuat keluaran. Simpan log, kunci, CSV dan arsip model di lokasi terbatas. Jangan mempublikasikan CSV per kasus. SHA256SUMS mencatat integritas berkas paket.

## Posisi ilmiah
Data berasal dari 38 jendela yang sudah digunakan dan dipilih menurut jadwal, bukan sampel acak. Hitungan satu jam bersifat retrospektif; ini bukan bukti real-time atau data eksternal baru. Kelompok kejadian dapat saling bergantung. Hasil ini mempersiapkan pemilihan kasus kandidat dan non-kandidat untuk telaah, bukan validasi framework, bukti recall, atau pembuktian false alert.
