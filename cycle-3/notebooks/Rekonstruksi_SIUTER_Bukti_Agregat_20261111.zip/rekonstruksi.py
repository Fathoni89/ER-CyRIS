import argparse,csv,io,zipfile,hashlib,importlib.util,json,gzip
from collections import Counter
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--log',required=True);p.add_argument('--converter',required=True);p.add_argument('--kasus',required=True);p.add_argument('--out',required=True);a=p.parse_args()
log,converter,archive,out=map(Path,[a.log,a.converter,a.kasus,a.out]);out.mkdir(parents=True,exist_ok=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
with zipfile.ZipFile(archive) as z:
 prior=json.loads(z.read('hasil/hasil_pilot.json'));candidates=list(csv.DictReader(io.TextIOWrapper(z.open('hasil/kasus_pseudonim_RESTRICTED.csv'),encoding='utf-8-sig')))
assert prior['status']=='COMPLETE_AGGREGATE_MATCH_CASE_EXPORT' and all(prior['aggregate_reproduction_checks'].values())
h=sha(log);assert prior['input_hashes']['laravel.log.gz']==h and prior['input_hashes']['siuter_log_to_dataset.py']==sha(converter)
assert len(candidates)==46 and all(x['raw_log_sha256']==h for x in candidates)
cand={int(r['header_line_1based_decompressed']):r for r in candidates};assert len(cand)==len(candidates)
spec=importlib.util.spec_from_file_location('siuter_converter',converter);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
windows=[f'2026-10-{d:02d} {h:02d}' for d in range(1,14) for h in (0,8,16) if d<13 or h<16]; selected_set=set(windows)
rows=[];per_window=Counter();seen=set();n_invalid=0;line0=None;others=[];selected=False;header_no=0;limited=False

def finish():
 global n_invalid,limited
 if not selected:return
 ent=m.parse_log_entry(line0,' '.join(others))
 if not ent or not isinstance(ent.get('ctx'),dict):n_invalid+=1;return
 ident=hashlib.sha256((h+':'+str(header_no)).encode()).hexdigest()[:20]
 is_cand=header_no in cand
 if is_cand:
  original=cand[header_no];assert original['case_id']==ident and original['timestamp_log_timezone_unknown']==ent['ts_str'];seen.add(header_no)
 rows.append({'case_id':ident,'header_line_1based_decompressed':header_no,'timestamp_log_timezone_unknown':ent['ts_str'],'log_level':ent['level'],'group_from_archived_candidate_set':'CANDIDATE_ARCHIVED' if is_cand else 'NON_CANDIDATE_COMPLEMENT','score_individual_available':'NO' if not is_cand else 'SEE_CANDIDATE_ARCHIVE'})
with gzip.open(log,'rt',encoding='utf-8',errors='replace') as f:
 for n,raw in enumerate(f,start=1):
  if raw.startswith('[20'):
   finish();header_no=n;line0=raw.rstrip();others=[];selected=len(raw)>=15 and raw[1:14] in selected_set
   if selected:per_window[raw[1:14]]+=1
  elif selected:
   if sum(map(len,others))<1048576:others.append(raw.rstrip())
   else:limited=True
 finish()
assert not n_invalid and not limited and len(rows)==prior['stage']['model_and_replay']['n_evaluated']
assert {w:per_window[w] for w in windows}==prior['stage']['parse']['records_per_window']
assert seen==set(cand) and len({x['case_id'] for x in rows})==len(rows)
levels=Counter(x['log_level'] for x in rows);assert dict(levels)==prior['stage']['feature_construction']['log_level_counts']
non=[x for x in rows if x['group_from_archived_candidate_set']=='NON_CANDIDATE_COMPLEMENT'];assert len(non)==len(rows)-len(candidates)
by_level=dict(sorted(Counter(x['log_level'] for x in non).items()));assert by_level=={'DEBUG':836,'INFO':965,'WARNING':6}
with (out/'non_kandidat_1807_RESTRICTED.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(non[0]));w.writeheader();w.writerows(non)
summary={'status':'COMPLETE_RECONSTRUCTED_COMPLEMENT_FROM_ARCHIVE','population':len(rows),'archived_candidate_count':len(candidates),'noncandidate_count':len(non),'noncandidate_levels':by_level,'checks':{'input_hashes_match':True,'all_38_window_counts_match':True,'candidate_lines_ids_timestamps_match':True,'all_levels_match':True,'ids_unique':True},'hashes':{'log_gz':h,'converter':sha(converter),'candidate_archive':sha(archive)},'limits':['Non-candidates are complement of archived candidate set; no model or SHAP recomputation','Archived aggregate match does not independently verify every original prediction','No individual detector probability is available for non-candidates in this output','Historically used nonrandom windows; not an independent holdout','Line-linked pseudonyms and timestamps are restricted, not anonymous','No outcome label or organizational incident confirmation']}
(out/'hasil_agregat.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2,ensure_ascii=False))
