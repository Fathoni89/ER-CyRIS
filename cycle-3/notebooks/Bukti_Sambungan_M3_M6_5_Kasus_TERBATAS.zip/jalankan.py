"""Komposisi keluaran tersimpan M3-M4 dan fungsi acuan M5-M6; bukan M1-M6 end-to-end."""
import collections,datetime,hashlib,json,platform
from pathlib import Path
from ercyris_contract import risk,handoff,authorize,VERSION
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((P/'masukan_5_kasus_TERBATAS.json').read_text())
if len(rows)!=5 or len({r['label'] for r in rows})!=5:raise ValueError('Masukan bukan lima kasus unik yang diharapkan')
records=[]
for r in rows:
 for scenario,key in [('sumber_belum_terverifikasi','m4_source_unverified'),('asumsi_sumber_valid','m4_source_assumed_valid')]:
  m4=r[key]; stat=m4['status']
  rr=risk(stat,None,None,None,None,None,None,None)
  missing=[v for v in rr['reasons'] if v not in ('RISK_POLICY_UNAVAILABLE','M4_NOT_ACCEPTED','NO_ALERT')]
  reason='SOURCE_UNVERIFIED' if scenario=='sumber_belum_terverifikasi' else 'M4_REVIEW'
  hh=handoff(stat,None,missing,None,m4_reason=reason)
  aa=authorize(hh['actionable'],None,None,prior_reason=hh['reasons'][0] if hh['reasons'] else None)
  records.append({'kasus':r['label'],'skenario':scenario,'m3':{'status_tersimpan':r['m3_status'],'x_tersimpan':r['x']},'m4_tersimpan':m4,'m5_hasil_aktual':rr,'handoff_hasil_aktual':hh,'m6_hasil_aktual':aa})
flow=collections.Counter((x['skenario'],x['m4_tersimpan']['status'],x['m5_hasil_aktual']['status'],x['handoff_hasil_aktual']['status'],x['m6_hasil_aktual']['status']) for x in records)
expect={('sumber_belum_terverifikasi','abstain','NOT_INVOKED','ESCALATE_FOR_REVIEW','NO_ACTIONABLE_RECOMMENDATION'):5,('asumsi_sumber_valid','warn','NOT_INVOKED','ESCALATE_FOR_REVIEW','NO_ACTIONABLE_RECOMMENDATION'):2,('asumsi_sumber_valid','accept','RISK_NOT_COMPUTABLE','ESCALATE_FOR_REVIEW','NO_ACTIONABLE_RECOMMENDATION'):3}
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'versi_fungsi':VERSION,'python':platform.python_version(),'input_sha256':sha(P/'masukan_5_kasus_TERBATAS.json'),'kode_sha256':{'jalankan.py':sha(P/'jalankan.py'),'ercyris_contract.py':sha(P/'ercyris_contract.py')},'jumlah_kasus':5,'jumlah_pasangan_kasus_skenario':len(records),'hasil':[{'skenario':k[0],'m4_tersimpan':k[1],'m5':k[2],'handoff':k[3],'m6':k[4],'jumlah':v} for k,v in sorted(flow.items())],'kesesuaian_dengan_ekspektasi_kondisi':dict(flow)==expect,'batas':['Masukan M3 dan M4 berasal dari keluaran tersimpan; tidak menjalankan M1, M2, model, SHAP, atau M4 ulang.','Skenario sumber valid dan masukan kritis tersedia adalah asumsi; bukan verifikasi asal.','Seluruh masukan risiko dan kewenangan sengaja tidak disediakan; bukan penilaian seluruh arsip organisasi.','Fungsi M5 dan M6 menggunakan kontrak acuan, tanpa penerapan otomatis atau tindakan operasional.','Ekspektasi berdasarkan hasil tersimpan terdahulu, bukan acuan kebenaran insiden atau risiko.','Lima kasus dipilih dari 46; dua skenario bukan sepuluh insiden.']}
(P/'hasil_per_kasus_TERBATAS.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
(P/'ringkasan_agregat.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
if dict(flow)!=expect:raise SystemExit('Hasil tidak sesuai ekspektasi; periksa output.')
