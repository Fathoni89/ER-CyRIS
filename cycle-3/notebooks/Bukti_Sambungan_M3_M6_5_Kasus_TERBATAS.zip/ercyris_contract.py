"""Selected BEEI contracts with supplied inputs. Not a full M1–M6 system."""
import math
from numbers import Real
VERSION='ercyris-bab7-contract-0.1'

def _valid_number(v):
 return isinstance(v,Real) and not isinstance(v,bool) and math.isfinite(v)

def _score(v):
 return _valid_number(v) and 0<=v<=1

def explanation(phi,probe,k):
 """Eq (3)-(5): ties resolved by ascending feature index; exact zero convention."""
 phi=list(phi);probe=list(probe)
 if len(phi)!=len(probe) or not phi or not isinstance(k,int) or isinstance(k,bool) or not 1<=k<=len(phi):
  raise ValueError('Equal nonempty vectors and 1 <= k <= feature count are required')
 if not all(_valid_number(v) for v in list(phi)+list(probe)):
  return {'status':'EXPLANATION_UNAVAILABLE','J':None,'B':None,'S':None,'x':None,'reasons':['INVALID_ATTRIBUTION']}
 t0=set(sorted(range(len(phi)),key=lambda j:(-abs(phi[j]),j))[:k]);t1=set(sorted(range(len(phi)),key=lambda j:(-abs(probe[j]),j))[:k]);u=t0|t1
 j=len(t0&t1)/len(u) if u else None
 den=sum(abs(v) for v in phi)+sum(abs(v) for v in probe)
 b=1-sum(abs(x-y) for x,y in zip(phi,probe))/den if den else None
 compared=[i for i in sorted(u) if phi[i]!=0 and probe[i]!=0]
 s=sum((phi[i]>0)==(probe[i]>0) for i in compared)/len(compared) if compared else None
 reasons=[]
 if j is None:reasons.append('TOPK_UNAVAILABLE')
 if b is None:reasons.append('MAGNITUDE_UNDEFINED')
 if s is None:reasons.append('SIGN_UNDEFINED')
 return {'status':'EXPLANATION_UNAVAILABLE' if reasons else 'EXPLANATION_AVAILABLE','J':j,'B':b,'S':s,'x':None if reasons else (j+b+s)/3,'reasons':reasons}

def m4(score,theta,source_ok,critical_missing,q,x,tau_d,tau_x,tau_q):
 if not _score(score) or not _valid_number(theta) or not 0<=theta<1:
  return {'status':'DETECTION_UNAVAILABLE','reasons':['DETECTION_UNAVAILABLE'],'margin':None}
 if score<theta:return {'status':'no_alert','reasons':[],'margin':None}
 if not all(_score(v) for v in (tau_d,tau_x,tau_q)):raise ValueError('Explicit thresholds in [0,1] are required')
 margin=min(1,max(0,(score-theta)/(1-theta)))
 reasons=[]
 if source_ok is not True:reasons.append('SOURCE_UNVERIFIED')
 if critical_missing is not False:reasons.append('CRITICAL_FIELD_UNAVAILABLE')
 if not _score(q):reasons.append('COMPLETENESS_UNAVAILABLE')
 if reasons:return {'status':'abstain','reasons':reasons,'margin':margin}
 d=margin>=tau_d;xp=_score(x) and x>=tau_x;goodq=q>=tau_q
 if not d:reasons.append('MARGIN_BELOW_THRESHOLD')
 if not _score(x):reasons.append('EXPLANATION_UNAVAILABLE')
 elif not xp:reasons.append('EXPLANATION_BELOW_THRESHOLD')
 if not goodq:reasons.append('COMPLETENESS_BELOW_THRESHOLD')
 status='abstain' if not d and not xp else 'accept' if d and xp and goodq else 'warn'
 return {'status':status,'reasons':reasons,'margin':margin}

def risk(m4_status,threat_valid,asset_valid,scenario_valid,likelihood,cia,policy_valid,band_map):
 if m4_status=='no_alert':return {'status':'NOT_INVOKED','risk':None,'reasons':['NO_ALERT']}
 if m4_status in ('warn','abstain'):return {'status':'NOT_INVOKED','risk':None,'reasons':['M4_NOT_ACCEPTED']}
 reasons=[]
 if m4_status!='accept':reasons.append('M4_NOT_ACCEPTED')
 for cond,reason in [(threat_valid,'THREAT_UNAVAILABLE'),(asset_valid,'ASSET_UNAVAILABLE'),(scenario_valid,'SCENARIO_UNAVAILABLE'),(policy_valid,'RISK_POLICY_UNAVAILABLE')]:
  if cond is not True:reasons.append(reason)
 if not isinstance(likelihood,int) or isinstance(likelihood,bool) or likelihood not in range(1,6):reasons.append('LIKELIHOOD_UNAVAILABLE')
 if not isinstance(cia,(tuple,list)) or len(cia)!=3 or any(not isinstance(v,int) or isinstance(v,bool) or v not in range(1,6) for v in cia):reasons.append('IMPACT_UNAVAILABLE')
 if not isinstance(band_map,dict) or set(band_map)!=set(range(1,26)) or any(not isinstance(band_map[i],str) or not band_map[i] for i in range(1,26)):reasons.append('RISK_BAND_MAP_UNAVAILABLE')
 if reasons:return {'status':'RISK_NOT_COMPUTABLE','risk':None,'reasons':reasons}
 impact=max(cia);r=likelihood*impact
 return {'status':'RISK_COMPUTED','likelihood':likelihood,'impact':impact,'risk':r,'band':band_map[r],'reasons':[]}

def handoff(m4_status,policy_valid,missing_reasons,matches,m4_reason='M4_REVIEW'):
 if m4_status=='no_alert':return {'status':'no_alert','reasons':[],'actionable':False}
 if m4_status in ('warn','abstain'):return {'status':'ESCALATE_FOR_REVIEW','reasons':[m4_reason],'actionable':False}
 if m4_status!='accept':raise ValueError('M4 status must be determined')
 reasons=list(missing_reasons)
 if policy_valid is not True:return {'status':'ESCALATE_FOR_REVIEW','reasons':['RISK_POLICY_UNAVAILABLE']+reasons,'actionable':False}
 if reasons:return {'status':'REQUEST_MORE_EVIDENCE','reasons':reasons,'actionable':False}
 if not isinstance(matches,int) or isinstance(matches,bool) or matches<0:raise ValueError('A valid count of supplied matches is required')
 if matches==0:return {'status':'ESCALATE_FOR_REVIEW','reasons':['NO_PLAYBOOK_MATCH'],'actionable':False}
 if matches>1:return {'status':'POLICY_CONFLICT','reasons':['MULTIPLE_PLAYBOOK_MATCHES'],'actionable':False}
 return {'status':'RECOMMENDATION_AVAILABLE','reasons':[],'actionable':True}

def authorize(actionable,permission,approval,prior_reason=None):
 if actionable is not True:return {'status':'NO_ACTIONABLE_RECOMMENDATION','reasons':[prior_reason] if prior_reason else [],'actual_action':None}
 if permission not in ('denied','allowed','unknown') or approval not in ('granted','pending','unknown'):raise ValueError('Invalid supplied authorization state')
 reasons=[]
 if permission=='denied':reasons.append('PERMISSION_DENIED')
 if permission=='unknown':reasons.append('PERMISSION_UNAVAILABLE')
 if approval=='unknown':reasons.append('APPROVAL_UNAVAILABLE')
 if approval=='pending':reasons.append('APPROVAL_NOT_GRANTED')
 status='AUTHORIZATION_BLOCKED' if permission=='denied' else 'AUTHORIZATION_UNAVAILABLE' if permission=='unknown' or approval=='unknown' else 'PENDING_AUTHORIZATION' if approval=='pending' else 'AUTHORIZED_FOR_HUMAN_EXECUTION'
 return {'status':status,'reasons':reasons,'actual_action':None}
