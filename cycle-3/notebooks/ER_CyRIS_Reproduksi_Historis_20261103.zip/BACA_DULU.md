# Pemeriksaan reproduksi historis Siklus 3 — 3 November 2026

## Hasil yang berhasil

Dari dataset yang diserahkan dan konfigurasi dalam arsip, skrip `cek_reproduksi.py` mengulangi kebijakan seleksi pola fitur dan pembagian temporal historis. Semua tujuh statistik audit serta jumlah baris, waktu awal/akhir dan jumlah label pada empat partisi sesuai arsip. Label test pada 5.004 baris sesuai urutannya dengan prediksi tersimpan untuk masing-masing model; label cocok tidak menjamin semua nilai fitur identik. Arsip tidak menyimpan hash dataset yang dapat dipakai membuktikan identitas seluruh file.

Prediksi tersimpan pada `diagnostic_error_analysis.csv` dibandingkan dengan ambang tersimpan 0,95: 0 ketidaksesuaian untuk kedua model. Confusion matrix dan F1 serta precision, recall, AP, ROC-AUC, Brier dan FAR dihitung ulang dari prediksi tersimpan; hasil cocok dengan ringkasan arsip dalam batas pembulatan floating point. Kedua model: TP=352, FP=0, FN=70, TN=4.582, F1=0,9095607235. AP menggunakan average_precision_score.

## Batas dan hambatan

Model, preprocessor dan kalibrator belum berhasil dimuat dan dijalankan di lingkungan pemeriksaan ini: `xgboost` tidak tersedia; upaya instalasi versi arsip tidak menemukan distribusi pada lingkungan ini. `hasil_cek_model.json` merekam BLOCKED dan bukan hasil lulus. Python yang tersedia 3.12, sedangkan arsip mencatat Python 3.13.15 dan versi paket tertentu. Model tersimpan berformat pickle/joblib dan harus dimuat hanya dari sumber yang dipercaya; format ini dapat menjalankan kode saat dimuat.

Ini adalah audit ulang prediksi yang sudah tersimpan, bukan re-eksekusi model atau validasi independen. Seleksi kelompok fitur berlabel konflik dilakukan pada seluruh data sebelum pemisahan temporal; pelaksanaan ini menirukan prosedur lama, bukan mengesahkannya untuk eksperimen baru. Label SIUTER dibentuk berdasarkan aturan dan fitur hitungan satu jam memasukkan kejadian kemudian dalam jam itu. Hasil tidak membuktikan deteksi real-time atau insiden keamanan terkonfirmasi dan belum menguji M3–M6 terbaru.

## Isi

- `cek_reproduksi.py`: menjalankan audit data dan menghitung ulang metrik dari prediksi tersimpan.
- `hasil_reproduksi.json` dan `.txt`: hasil aktual; tidak berisi baris data atau prediksi per individu.
- `cek_model_arsip.py`: upaya memuat model, transformasi dan kalibrator, lalu membandingkan output pada test dengan prediksi tersimpan.
- `hasil_cek_model.json` dan `.txt`: hasil aktual di lingkungan ini, yaitu BLOCKED.
- `Reproduksi_Model_SIUTER_Colab.ipynb`: pilihan untuk menjalankan ulang pemeriksaan dan mencoba model di Colab dengan salinan dataset dan arsip. Notebook telah diperiksa sintaks sel Python, tetapi belum dijalankan di Colab. Instalasi versi paket bisa gagal; Python versi berbeda juga dapat memengaruhi kompatibilitas.
- `MANIFEST_SHA256.json`: hash file dalam paket.

## Menjalankan pada Google Colab

Buka `Reproduksi_Model_SIUTER_Colab.ipynb`, jalankan setiap sel dan unggah dua file yang diminta: CSV SIUTER lama dan ZIP hasil Siklus 3. Jalankan hanya arsip yang Bapak percayai. Notebook membuat folder kerja baru dan menyediakan hasil agregat terpisah untuk diunduh. Jika instalasi/eksekusi gagal, simpan pesan dan hasilnya; jangan menyebut model berhasil direproduksi. Data SIUTER tidak dimasukkan dalam paket ini.

Output historis tidak berubah. Eksperimen framework baru memerlukan pemisahan periode dan fitur yang sesuai waktu keputusan, sumber alert yang benar-benar dapat diverifikasi, SHAP aktual, aturan M3–M4 sesuai paper, data pengembangan dan evaluasi yang sesuai, serta rekaman risiko/otorisasi untuk klaim M5–M6.
