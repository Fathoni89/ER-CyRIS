"""Attempt model replay in a controlled compatible Python environment.
Load only archive from the researcher: pickle/joblib can execute code.
The script never exports individual SIUTER records or predictions.
"""
import argparse,importlib,io,json,runpy,sys,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('dataset');p.add_argument('archive');a=p.parse_args();out={'status':'NOT_RUN','models':{},'error':None,'limits':['Replay of historical model is not an independent study.','Archived scores use original rule-based SIUTER labels and historical full-hour features.']}
try:
 modules={name:importlib.import_module(name) for name in ['numpy','pandas','sklearn','xgboost','shap','imblearn','cloudpickle','joblib']}
 sys.argv=['cek_reproduksi.py',a.dataset,a.archive];g=runpy.run_path('cek_reproduksi.py');np=modules['numpy'];cp=modules['cloudpickle'];joblib=modules['joblib'];parts=g['parts'];feature_cols=g['features'];stored=g['pred'];metrics=g['metrics']
 with zipfile.ZipFile(a.archive) as z:
  pre=cp.load(io.BytesIO(z.read('results_s3_v2/preprocessor_v2.pkl')))
  raw=parts['test'][feature_cols].apply(modules['pandas'].to_numeric,errors='coerce').to_numpy(dtype=float);X=pre.transform(raw)
  for name in ['XGBoost','RandomForest']:
   model=joblib.load(io.BytesIO(z.read(f'results_s3_v2/model_{name}.joblib')));cal=cp.load(io.BytesIO(z.read(f'results_s3_v2/calibrator_{name}.pkl')));prob=np.asarray(cal.predict(model.predict_proba(X)[:,1])).reshape(-1);saved=stored[stored.model==name].sort_values('test_index');old=saved.calibrated_probability.to_numpy();threshold=float(metrics.set_index('model').loc[name].threshold);max_diff=float(np.max(np.abs(prob-old)));label_diff=int(np.sum((prob>=threshold).astype(int)!=saved.y_pred.to_numpy()));out['models'][name]={'rows':len(prob),'max_abs_probability_difference':max_diff,'prediction_disagreements':label_diff,'probability_tolerance':1e-8,'pass':bool(max_diff<=1e-8 and label_diff==0)}
 out['status']='REPRODUCED' if all(v['pass'] for v in out['models'].values()) else 'DIFFERENCES_FOUND'
except Exception as e:
 out['status']='BLOCKED';out['error']={'type':type(e).__name__,'message':str(e)[:400]}
Path('hasil_cek_model.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));sys.exit(0 if out['status']=='REPRODUCED' else 2)
