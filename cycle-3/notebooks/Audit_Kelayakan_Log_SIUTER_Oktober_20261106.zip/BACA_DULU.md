# Audit kelayakan log SIUTER Oktober untuk M3 dan M4

Tanggal: 6 November 2026. Audit deskriptif ini tidak menjalankan model, SHAP, M4, atau penilaian pakar. Tidak ada log asli, isi kasus, atau identitas yang disalin ke paket.

## Berkas sumber

1. laravel.log.gz (SHA-256 dicatat pada output/hasil_agregat.json): salinan log yang tersedia dari percakapan, bukan bukti terverifikasinya asal sumber.
2. siuter_dataset.csv lama: 480.461 baris; hash dalam hasil.
3. ercyris_siklus3_corrected_validation_v2_outputs.zip: arsip model, konfigurasi dan pembagian data XGBoost historis; hash dalam hasil.
4. siuter_log_to_dataset.py: kode yang pernah diberikan; hash dalam hasil. Kesesuaian aturan dengan dataset lama sudah pernah diperiksa tetapi riwayat eksekusinya belum terbukti.

## Hasil dan keputusan

- Log terdekompresi berukuran 633.414.644 byte. Hash 371.357.850 byte awal sama dengan nilai hash yang tercatat untuk log lama pada Temuan_Sumber_Pakar_Log_SIUTER_20261106.md. Audit ini tidak membandingkan kembali byte dengan log lama sebagai file terpisah. Byte berikutnya dimulai pada header.
- Setelah batas tersebut terdapat 816.186 header, minimum 11 April 2026 08:06:15 dan maksimum 13 Oktober 2026 12:24:10. Ada dua penurunan waktu antara header berurutan; zona waktu tidak diketahui. Untuk dataset CSV lama maksimum 11 April 2026 08:03:50, sedangkan test terpilih dalam arsip berakhir 11 April 2026 07:56:51. Perbedaan periode tidak memastikan independensi observasi.
- Penambahan periode ini pernah dianalisis dalam eksperimen temporal terdahulu dengan HistGradientBoosting. Bukan holdout baru yang belum pernah dilihat. Hasil 8.877 kandidat, 7.913 accept, 964 warn berasal dari laporan lama, belum dijalankan ulang di audit ini; tidak disatukan dengan eksperimen XGBoost 352 kandidat.
- Sampel acak reservoir 200 header tambahan (seed 20261106) dapat dikenali parser yang diberikan; 195 memiliki konteks JSON tidak kosong, 26 ada semester_aktif, 22 ada session_id, dan tidak ada user_ip atau nuptk yang tidak kosong. Angka sampel bukan distribusi seluruh kandidat dan tanpa konteks bukan berarti insiden tidak ada. Parser memakai format kode lama, termasuk pembatasan msg dan perilaku JSON aslinya.
- Sampel menunjukkan kemungkinan untuk menyiapkan telaah teknis terbatas, bukan bahwa seluruh peristiwa sudah layak dinilai. Tidak ada kasus individual yang dipilih, dinilai, atau disamarkan pada audit ini. Sebelum membuat paket kasus, tentukan unit peristiwa, pemilihan, bukti yang aman, dan pemeriksaan kelayakan manual.
- Arsip XGBoost memerlukan 11 fitur dasar dan preprocessing tersimpan (lihat JSON). Raw log bukan CSV dengan fitur tersebut. Ketersediaan nama/model belum membuktikan transformasi atau prediksi benar untuk log baru. Konverter terdahulu menghitung total IP/sesi untuk seluruh jam: berpotensi menggunakan kejadian sesudah peristiwa. Jika dipakai, hanya cocok untuk analisis retrospektif setelah penutupan jendela dengan pengukuran latensi yang sesuai; versi kausal adalah perubahan fitur dan perlu pengujian tersendiri. Jangan menganggap ambang lama otomatis valid.
- Ringkasan 352 kandidat lama telah memiliki M3 dan perbandingan M4 eksploratif; penambahan log Oktober belum dibuktikan terproses oleh model XGBoost + M3 + aturan M4 paper. Penerapan Table 4 lengkap, penentuan ambang, pemeriksaan sumber dan acuan penelaah harus diperiksa sebelum kesimpulan.

## Menjalankan ulang

Python 3 dengan pandas dan empat file sumber tepercaya. Dari folder paket:

python audit.py /path/laravel.log.gz /path/siuter_dataset.csv /path/ercyris_siklus3_corrected_validation_v2_outputs.zip /path/siuter_log_to_dataset.py /path/output_baru

Skrip mengimpor kode konversi yang diberikan; hanya gunakan salinan yang dipercaya. Berkas kode konversi harus sesuai hash yang tercatat. Hasil adalah agregat saja, tetapi jalankan di penyimpanan terbatas karena memori membaca isi log. Pemeriksaan tidak memodifikasi file sumber.
