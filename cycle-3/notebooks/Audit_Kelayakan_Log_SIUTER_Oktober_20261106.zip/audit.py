import gzip, hashlib, re, json, random, sys, importlib.util, csv, zipfile, platform
from pathlib import Path
from collections import Counter
from datetime import datetime
p=Path(sys.argv[1]); old=Path(sys.argv[2]); archive=Path(sys.argv[3]); converter=Path(sys.argv[4]); out=Path(sys.argv[5]); boundary=371357850
spec=importlib.util.spec_from_file_location('conv',converter);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
h=hashlib.sha256(); pre=hashlib.sha256(); totalbytes=0; alln=0; addn=0; nonheaderadd=0; inv=0; backwards=0; previous=None; mn=None;mx=None; lev=Counter(); month=Counter(); sample=[]; seen=0;rng=random.Random(20261106); current=None; chunks=[]; included=False; at_boundary=None
rx=re.compile(rb'^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\] (\w+)\.(\w+): ')
def sample_record():
 global seen
 if current is None or not included:return
 seen+=1
 item=(current,b' '.join(chunks))
 if len(sample)<200: sample.append(item)
 else:
  idx=rng.randrange(seen)
  if idx<200:sample[idx]=item
with p.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
with gzip.open(p,'rb') as g:
 for line in g:
  before=totalbytes; totalbytes+=len(line)
  if before<boundary:pre.update(line[:boundary-before])
  match=rx.match(line)
  if match:
   sample_record();current=line[:1048576];chunks=[];alln+=1;included=before>=boundary
   if included:
    addn+=1
    if at_boundary is None:at_boundary=(before==boundary)
    ts=match.group(1).decode();lvl=match.group(3).decode();lev[lvl]+=1;month[ts[:7]]+=1
    try:datetime.strptime(ts,'%Y-%m-%d %H:%M:%S')
    except ValueError:inv+=1;continue
    if previous is not None and ts<previous:backwards+=1
    previous=ts;mn=ts if mn is None or ts<mn else mn;mx=ts if mx is None or ts>mx else mx
  elif included:
   nonheaderadd+=1
   if sum(map(len,chunks))<1048576:chunks.append(line[:1048576])
 sample_record()
counts=Counter()
for line,more in sample:
 e=m.parse_log_entry(line.decode('utf8','replace').rstrip(),more.decode('utf8','replace').rstrip())
 if not e:counts['parser_failed']+=1;continue
 counts['parser_ok']+=1;ctx=e['ctx'];counts['has_context_nonempty']+=bool(ctx)
 if isinstance(ctx,dict):
  u=ctx.get('siuter_user_data',{})
  if isinstance(u,dict):counts['role_source_nuptk_nonempty']+=u.get('nuptk') not in (None,'')
  counts['semester_aktif_nonempty']+=ctx.get('semester_aktif') not in (None,'')
  counts['session_id_nonempty']+=ctx.get('session_id') not in (None,'')
  counts['user_ip_nonempty']+=ctx.get('user_ip') not in (None,'')
with zipfile.ZipFile(archive) as z: split=list(csv.DictReader(z.read('results_s3_v2/temporal_split.csv').decode().splitlines()));config=json.loads(z.read('results_s3_v2/config.json'))
with old.open('rb') as f:oldhash=hashlib.file_digest(f,'sha256').hexdigest()
out.mkdir(parents=True,exist_ok=True)
result={'audit':'deskriptif; bukan hasil pengujian model','python':platform.python_version(),'log_gzip_sha256':h.hexdigest(),'old_csv_sha256':oldhash,'converter_sha256':hashlib.sha256(converter.read_bytes()).hexdigest(),'model_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'decompressed_bytes':totalbytes,'prefix_bytes':boundary,'prefix_sha256':pre.hexdigest(),'boundary_starts_header':at_boundary,'all_header_count':alln,'additional_header_count':addn,'additional_nonheader_lines':nonheaderadd,'additional_min_time':mn,'additional_max_time':mx,'additional_timestamp_backwards':backwards,'invalid_header_timestamps':inv,'additional_by_level':dict(lev),'additional_by_month':dict(sorted(month.items())),'sample':{'method':'reservoir random seed 20261106, matching additional header entries, max 200, parse via supplied code, no case data retained','eligible_seen':seen,'sample_n':len(sample),'counts':dict(counts)},'historical_split':split,'historical_base_features':config['BASE_FEATURES'],'limits':['Prefix comparison uses previously documented hash; old original log not loaded in this audit.','Timestamp timezone and actual source authenticity not verified.','Additional period already analyzed historically; not untouched independent holdout.','Parser sample is not proof of representativeness of candidate alerts or technical adequacy of every case.','Only parsing/source feasibility audited; no preprocessing, model prediction, SHAP, or M4 evaluation performed.','Old converter uses future full-hour counts; not suitable for event-time claim without corrected procedure.']}
(out/'hasil_agregat.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result,indent=2,ensure_ascii=False))
