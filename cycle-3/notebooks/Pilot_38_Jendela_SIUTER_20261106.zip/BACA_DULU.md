# Pilot 38 jendela SIUTER Oktober

## Tujuan
Melanjutkan pilot sebelumnya yang menghasilkan 0 kandidat pada 12 Oktober pukul 10.00. Pemeriksaan ini menggunakan 38 jendela satu jam dengan jam yang ditetapkan sebelum keluaran: pukul 00.00, 08.00 dan 16.00 pada 1–12 Oktober serta pukul 00.00 dan 08.00 pada 13 Oktober 2026. Zona waktu log belum diketahui. Ini pemilihan terjadwal, bukan sampel acak dan bukan bukti populasi. Data Oktober sudah pernah dianalisis, sehingga bukan evaluasi independen.

## Hasil aktual lokal
Sebanyak 1.853 header di 31 jendela berisi berhasil dibaca dan dibentuk menjadi 11 kolom fitur; 7 jendela tidak memiliki header. Level: INFO 965, DEBUG 836, ERROR 46, WARNING 6. Fitur semester_aktif numerik tersedia 73/1.853. Terdapat nilai nol bawaan; jumlah kolom bernilai numerik bukan bukti bahwa sumber lengkap. Catatan ERROR bukan otomatis serangan atau kandidat. Tidak ada data individu atau log mentah di paket.

Model/replay terhenti karena xgboost, shap, dan cloudpickle tidak tersedia di lingkungan lokal. Tidak ada prediksi, jumlah kandidat, SHAP/M3, atau M4 pada 38 jendela. Hasil lokal ada di output/hasil_pilot.json, bukan hasil Colab. Uji kode pada log sintetis memastikan pemilihan waktu dan penghentian saat dependensi tidak tersedia; ini bukan pengujian kerangka pada data organisasi. Notebook disintaks per sel tetapi belum dijalankan di Colab.

## Colab
1. Buka Pilot_38_Jendela_SIUTER_Colab.ipynb di Google Colab dan jalankan sel berurutan. Instalasi membutuhkan internet; catat kesalahan jika paket tidak tersedia.
2. Unggah empat file yang sama dengan pilot sebelumnya: laravel.log.gz, siuter_dataset.csv lama, ercyris_siklus3_corrected_validation_v2_outputs.zip, dan siuter_log_to_dataset.py. Pastikan arsip model benar-benar tepercaya; pickle/joblib dapat menjalankan kode saat dibuka. Hash sumber ditulis pada hasil.
3. Notebook memeriksa pemutaran ulang prediksi historis sebelum memproses prediksi jendela Oktober. Jika replay gagal atau tidak ada kandidat, M3/M4 tidak dijalankan dan statusnya dicatat.
4. Unduh hasil_pilot_38_jendela_agregat.zip dan sampaikan arsip tersebut beserta error bila ada. Simpan log dan dataset secara terbatas; tidak disalin ke ZIP hasil.

## Interpretasi
Ambang detektor 0,95 dipertahankan. Jika ada kandidat, M3 memakai SHAP raw margin dan probe sintetis; skor ini bukan fidelity. M4 memakai versi eksploratif sederhana dengan ambang ilustratif; skenario sumber valid adalah asumsi, bukan autentikasi log dan bukan pelaksanaan lengkap Table 4. Angka level ERROR/WARNING atau label berbasis aturan tidak membuktikan serangan, insiden, atau false alert. Fitur hitungan satu jam memakai semua peristiwa dalam jam tersebut sehingga hasil retrospektif, tidak membuktikan deteksi saat kejadian. Tidak menguji M5/M6 dan tidak memberikan validitas atau reliabilitas keseluruhan framework.
