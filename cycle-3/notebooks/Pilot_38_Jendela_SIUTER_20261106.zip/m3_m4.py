"""Historical exploratory M3 and counterfactual M4, not source validation."""
import math
import numpy as np

def diagnostics(phi,probe,k):
 a=np.asarray(phi,dtype=float);b=np.asarray(probe,dtype=float)
 if a.ndim!=1 or b.shape!=a.shape or len(a)==0 or not 1<=k<=len(a):raise ValueError('attribution shapes/k invalid')
 if not np.isfinite(a).all() or not np.isfinite(b).all():return {'J':None,'B':None,'S':None,'x':None,'status':'EXPLANATION_UNAVAILABLE','reason':'INVALID_ATTRIBUTION'}
 # deterministic ties: lower feature index wins
 topa=set(sorted(range(len(a)),key=lambda j:(-abs(a[j]),j))[:k]);topb=set(sorted(range(len(a)),key=lambda j:(-abs(b[j]),j))[:k]);u=topa|topb;J=len(topa&topb)/len(u);den=float(np.abs(a).sum()+np.abs(b).sum());B=1-float(np.abs(a-b).sum())/den if den>0 else None;valid=[j for j in u if a[j]!=0 and b[j]!=0];S=sum(np.sign(a[j])==np.sign(b[j]) for j in valid)/len(valid) if valid else None
 if B is None or S is None:return {'J':J,'B':B,'S':S,'x':None,'status':'EXPLANATION_UNAVAILABLE','reason':'MAGNITUDE_OR_SIGN_UNDEFINED'}
 return {'J':J,'B':B,'S':S,'x':(J+B+S)/3,'status':'AVAILABLE','reason':None}

def score(v):return v is not None and isinstance(v,(int,float,np.number)) and not isinstance(v,(bool,np.bool_)) and math.isfinite(v) and 0<=v<=1

def route(p,theta,source,q,x,tau_d,tau_x,tau_q,with_x):
 if not score(p) or not score(theta) or theta>=1: return 'DETECTION_UNAVAILABLE'
 if p<theta:return 'no_alert'
 if source is not True or not score(q):return 'abstain'
 d=(p-theta)/(1-theta);D=d>=tau_d;Q=q>=tau_q
 if not with_x:return 'accept' if D and Q else 'warn'
 X=score(x) and x>=tau_x
 if not D and not X:return 'abstain'
 return 'accept' if D and X and Q else 'warn'
