"""Limited retrospective pilot; no log lines or case-level content exported."""
import argparse, gzip, importlib.util, importlib, hashlib, io, json, platform, re, runpy, sys, zipfile
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd
P=argparse.ArgumentParser();P.add_argument('--log',required=True);P.add_argument('--converter',required=True);P.add_argument('--archive',required=True);P.add_argument('--old-data',required=True);P.add_argument('--replay',required=True);P.add_argument('--m3m4',required=True);P.add_argument('--out',required=True);a=P.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
results={'classification':'PILOT_RETROSPECTIVE_HISTORICAL_NOT_INDEPENDENT','window_start_inclusive':'2026-10-01 00:00:00','window_end_exclusive':'2026-10-13 09:00:00','timezone':'UNKNOWN','window_selection':'All complete scheduled hours 00, 08, 16 daily 1–12 October and 00, 08 on 13 October; 38 one-hour windows. Scheduled independent of outcomes; not a random sample.','dependencies':{},'stage':{},'input_hashes':{Path(p).name:sha(p) for p in [a.log,a.converter,a.archive,a.old_data,a.replay,a.m3m4]},'python':platform.python_version(),'privacy':'No raw entries or case-level data exported','notes':['Full-hour counts depend on full observation window and are retrospective, not per-event real time.','Missing identifiers mapped by legacy converter to zero or absent; zero does not establish feature availability.','Source authentication not established.','Prior October replay already used; no independent evaluation or operational validity.']}
def write():
 (out/'hasil_pilot.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
def status(name,value,**kw):results['stage'][name]={'status':value,**kw};write()
write()
try:
 spec=importlib.util.spec_from_file_location('converter',a.converter);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 windows=[f'2026-10-{d:02d} {h:02d}' for d in range(1,14) for h in (0,8,16) if d<13 or h<16]; window_set=set(windows); per_window=Counter();line0=None;others=[];selected=False;records=[];n_invalid=0;header_count=0;levels=Counter();limited=False
 def finish():
  global n_invalid,limited
  if not selected:return
  entry=mod.parse_log_entry(line0,' '.join(others))
  if not entry or not isinstance(entry.get('ctx'),dict):n_invalid+=1;return
  records.append(entry)
 with gzip.open(a.log,'rt',encoding='utf-8',errors='replace') as f:
  for raw in f:
   if raw.startswith('[20'):
    finish();line0=raw.rstrip();others=[];selected=len(raw)>=15 and raw.startswith('[20') and raw[1:14] in window_set
    if selected:header_count+=1;per_window[raw[1:14]]+=1
   elif selected:
    if sum(map(len,others))<1048576:others.append(raw.rstrip())
    else:limited=True
  finish()
 if not records:raise RuntimeError('No successfully parsed entries in selected window')
 if n_invalid or limited:raise RuntimeError('Some selected records failed parsing or exceeded the context bound; stop to prevent incomplete-feature claims')
 status('parse','COMPLETE',headers=header_count,parsed=len(records),invalid=n_invalid,scheduled_windows=len(windows),empty_windows=sum(per_window[w]==0 for w in windows),records_per_window={w:per_window[w] for w in windows})
 df=mod.build_dataset(records)
 with zipfile.ZipFile(a.archive) as z:cfg=json.loads(z.read('results_s3_v2/config.json'));old_env=json.loads(z.read('results_s3_v2/environment.json'))
 features=cfg['BASE_FEATURES'];missing=[f for f in features if f not in df.columns]
 if missing:raise RuntimeError('Missing required features: '+','.join(missing))
 raw=df[features].apply(pd.to_numeric,errors='coerce');q=raw.notna().mean(axis=1)
 status('feature_construction','COMPLETE',n=len(df),features=features,numeric_nonmissing={c:int(raw[c].notna().sum()) for c in features},zero_count={c:int((raw[c]==0).sum()) for c in ['is_dosen','sess_events_per_hour','ip_events_per_hour']},q_min=float(q.min()),q_max=float(q.max()),context_nonempty=int((raw['has_context']==1).sum()),log_level_counts={str(k):int(v) for k,v in df.log_level.value_counts().items()},note='Legacy one-hour counts use full selected hour; field defaults can hide unavailable input; no claim of true completeness.')
 for name in ['xgboost','shap','cloudpickle','joblib','sklearn']:
  try:
   lib=importlib.import_module(name);results['dependencies'][name]={'available':True,'version':getattr(lib,'__version__','unknown')}
  except Exception as e:results['dependencies'][name]={'available':False,'error':type(e).__name__}
 miss=[k for k,v in results['dependencies'].items() if not v['available']]
 results['archived_environment']=old_env
 if miss:
  status('model_and_replay','BLOCKED',reason='Missing or unloadable dependencies: '+', '.join(miss));status('M3_SHAP','NOT_RUN',reason='Model and replay must succeed first');status('M4','NOT_RUN',reason='Model and M3 must succeed first');results['status']='PARTIAL_BLOCKED';write();sys.exit(0)
 sys.argv=['cek_reproduksi.py',a.old_data,a.archive];g=runpy.run_path(a.replay);hist=g['result'];assert hist['audit_all_match'] and all(all(x['matches_archived'].values()) for x in hist['split_comparison']);assert all(x['label_mismatches_vs_reconstructed_test']==0 for x in hist['prediction_checks'])
 cp=importlib.import_module('cloudpickle');joblib=importlib.import_module('joblib');shap=importlib.import_module('shap')
 with zipfile.ZipFile(a.archive) as z:
  pre=cp.load(io.BytesIO(z.read('results_s3_v2/preprocessor_v2.pkl')));model=joblib.load(io.BytesIO(z.read('results_s3_v2/model_XGBoost.joblib')));cal=cp.load(io.BytesIO(z.read('results_s3_v2/calibrator_XGBoost.pkl')))
 oldraw=g['parts']['test'][features].apply(pd.to_numeric,errors='coerce');oldX=np.asarray(pre.transform(oldraw.to_numpy(dtype=float)),dtype=float);oldprob=np.asarray(cal.predict(model.predict_proba(oldX)[:,1]));old=g['pred'];old=old[old.model=='XGBoost'].sort_values('test_index');delta=float(np.max(np.abs(oldprob-old.calibrated_probability.to_numpy())));disagree=int(np.sum((oldprob>=.95).astype(int)!=old.y_pred.to_numpy()))
 if delta>1e-8 or disagree:raise RuntimeError('Historical replay mismatch; do not process target log')
 X=np.asarray(pre.transform(raw.to_numpy(dtype=float)),dtype=float);prob=np.asarray(cal.predict(model.predict_proba(X)[:,1]));idx=np.flatnonzero(prob>=.95);status('model_and_replay','COMPLETE',n_evaluated=len(X),historical_replay_max_difference=delta,historical_replay_disagreements=disagree,candidates=len(idx),detector_threshold=0.95,candidates_per_window={w:int(np.count_nonzero((df['timestamp'].str.slice(0,13).to_numpy()==w)&(prob>=.95))) for w in windows})
 if not len(idx):status('M3_SHAP','NOT_RUN',reason='No candidate at historical threshold');status('M4','NOT_RUN',reason='No candidate');results['status']='COMPLETE_NO_CANDIDATES';write();sys.exit(0)
 binary=np.asarray(pre.binary_feature_indices_,dtype=int);mask=np.ones(X.shape[1],dtype=bool);mask[binary]=False;Z=X[idx].copy();rng=np.random.RandomState(20261103);Zp=Z.copy();Zp[:,mask]=np.clip(Z[:,mask]+rng.normal(0,.01,size=(len(idx),int(mask.sum()))),0,1);ex=shap.TreeExplainer(model,feature_perturbation='tree_path_dependent',model_output='raw');v=np.asarray(ex.shap_values(Z),float);vp=np.asarray(ex.shap_values(Zp),float);base=float(np.asarray(ex.expected_value).reshape(-1)[0]);error0=float(np.max(np.abs(v.sum(1)+base-model.predict(Z,output_margin=True))));errorp=float(np.max(np.abs(vp.sum(1)+base-model.predict(Zp,output_margin=True))))
 if v.shape!=Z.shape or vp.shape!=Z.shape or not np.isfinite(error0+errorp) or max(error0,errorp)>1e-4:raise RuntimeError('SHAP shape or additivity check failed')
 spec=importlib.util.spec_from_file_location('m3m4',a.m3m4);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);diags=[r.diagnostics(x,y,10) for x,y in zip(v,vp)];status('M3_SHAP','COMPLETE',n=len(diags),available=sum(x['status']=='AVAILABLE' for x in diags),max_additivity_error_original=error0,max_additivity_error_probe=errorp,note='SHAP raw margin, synthetic noise, not fidelity')
 actual=Counter();basecase=Counter();withx=Counter();transitions=Counter()
 for n,j in enumerate(idx):
  x=diags[n]['x'];qq=float(q.iloc[j]);actual[r.route(float(prob[j]),.95,False,qq,x,.5,.7,.9,True)]+=1;b=r.route(float(prob[j]),.95,True,qq,x,.5,.7,.9,False);f=r.route(float(prob[j]),.95,True,qq,x,.5,.7,.9,True);basecase[b]+=1;withx[f]+=1;transitions[(b,f)]+=1
 status('M4','EXPLORATORY_SIMPLIFIED',actual_source_unverified=dict(actual),simulated_source_valid_baseline=dict(basecase),simulated_source_valid_with_m3=dict(withx),paired_transitions=[{'baseline':k[0],'with_m3':k[1],'n':v} for k,v in sorted(transitions.items())],note='Illustrative thresholds; source=true assumed; implementation not demonstrated equivalent to all Table 4 conditions')
 results['status']='COMPLETE_EXPLORATORY';write()
except Exception as e:
 results['status']='BLOCKED_ERROR';results['error']={'type':type(e).__name__,'message':str(e)[:500]};write();raise
