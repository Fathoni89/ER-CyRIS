import argparse,collections,csv,gzip,hashlib,io,json,math,re,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('aggregate');p.add_argument('restricted');p.add_argument('log');p.add_argument('output');a=p.parse_args()
def sha(path):
 with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
with zipfile.ZipFile(a.aggregate) as z:ag=json.loads(z.read('hasil/hasil_pilot.json'))
with zipfile.ZipFile(a.restricted) as z:
 rs=json.loads(z.read('hasil/hasil_pilot.json'));rows=list(csv.DictReader(io.TextIOWrapper(z.open('hasil/kasus_pseudonim_RESTRICTED.csv'),encoding='utf-8')))
assert ag==rs and len(rows)==46 and all(ag['aggregate_reproduction_checks'].values())
loghash=sha(a.log);assert all(r['raw_log_sha256']==loghash for r in rows)
trans=collections.Counter((r['assumed_source_baseline'],r['assumed_source_with_m3']) for r in rows)
assert trans=={('accept','accept'):44,('accept','warn'):2}
changed=[r for r in rows if r['simulated_changed']=='True'];assert len(changed)==2
lookup={int(r['header_line_1based_decompressed']):r for r in rows};assert len(lookup)==len(rows)
matched=0;tsmatched=0;levels=collections.Counter();changes=[]
with gzip.open(a.log,'rt',encoding='utf-8',errors='replace') as f:
 for n,line in enumerate(f,1):
  if n in lookup:
   v=lookup[n];m=re.match(r'^\[([^\]]+)\] \w+\.(\w+): ',line)
   if m:
    matched+=1;tsmatched+=m.group(1)==v['timestamp_log_timezone_unknown'];levels[m.group(2)]+=1
assert matched==tsmatched==46
for n,r in enumerate(changed,1):
 j,b,s,x=(float(r[c]) for c in ['J','B','S','x']);assert math.isclose(x,(j+b+s)/3,abs_tol=1e-12);assert float(r['p_calibrated'])>=.95 and x<.7 and r['source_status']=='UNVERIFIED'
 changes.append({'anonymous_label':'Kasus '+str(n),'p_calibrated':float(r['p_calibrated']),'margin_stored':float(r['margin']),'J':j,'B':b,'S':s,'x':x,'q_numeric':float(r['q_numeric_nonmissing_11']),'margin_pass':r['passes_margin_illustrative']=='True','x_pass':r['passes_x_illustrative']=='True','q_pass':r['passes_q_illustrative']=='True','source_unverified':r['source_unverified_decision'],'baseline_assumed_source':r['assumed_source_baseline'],'with_m3_assumed_source':r['assumed_source_with_m3']})
out={'analysis':'Audit hasil rekaman, bukan menjalankan ulang XGBoost atau SHAP','input_sha256':{'aggregate_zip':sha(a.aggregate),'restricted_zip':sha(a.restricted),'log_gzip':loghash},'checks':{'json_equal':ag==rs,'aggregate_checks_all_true':all(ag['aggregate_reproduction_checks'].values()),'csv_count':len(rows),'different_reference_lines':len(lookup),'hash_matches_all_rows':True,'header_and_timestamp_matches':tsmatched},'levels':dict(levels),'changed_cases':changes,'notes':['Prior aggregate had no per-case values: cannot prove identical individual scores across runs.','Header/timestamp match does not authenticate origin or confirm the incident.','Identical hashes and line refs depend on same compressed source bytes and line numbering.','All 46 have ERROR level: this is not an independent threat label or proof model used only this feature.','SHAP original raw margin; synthetic noise; source verified simulation; illustrative thresholds.','Full-hour feature counts are retrospective; threshold q numeric includes defaults.','Stored margin may slightly exceed 1 due to floating-point rounding; routing recomputes margin.']}
Path(a.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out,indent=2,ensure_ascii=False))
