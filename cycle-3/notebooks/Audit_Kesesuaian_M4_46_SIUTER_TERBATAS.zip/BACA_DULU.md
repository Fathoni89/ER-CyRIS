# Audit kesesuaian terbatas status M4 pada 46 kandidat SIUTER

Tujuan: membandingkan status hasil aturan pada 46 keluaran pilot yang tersimpan dengan kalkulator keputusan yang disusun dari urutan Table 4 pada BEEI_V2_Fathoni(6).docx. Tabel 4 dan keluaran pilot bukan sumber independen; audit ini dilakukan setelah hasil diketahui. Program tidak menjalankan ulang model, SHAP, proses sumber atau implementasi lengkap Table 4.

Sumber terbatas: kasus_46_RESTRICTED.zip; lokasi sebelumnya upload/kasus_46_RESTRICTED.zip. Tidak disertakan. Hash SHA-256 sumber ada di hasil_agregat.json. Berkas CSV internal menyimpan kode kasus, waktu dan nomor baris log; simpan terbatas. Kalkulator Table 4 pada script adalah hasil translasi dari tabel, bukan implementasi yang sudah diuji independen.

Metode: periksa bahwa p, threshold, q, x valid; hitung D, X dan Q proxy dari p dan ambang yang dipakai pilot (0,5; 0,7; 0,9); bandingkan dengan flags tersimpan. Hitung status Table 4 pada (1) source_verified false -> H=1, dan (2) simulasi source valid serta semua field kritis diasumsikan ada -> H=0. Bandingkan status dengan output pilot per kasus. Q memakai q jumlah kolom numerik terisi, tidak memverifikasi kelengkapan observasi asal. Asumsi ini tidak membuktikan input organisasi memadai.

Yang diuji hanya kesamaan kategori status pada data yang ada. Identitas sumber, unit observasi, definisi field kritis, alasan kode keluaran, status SHAP unavailable, non-candidate, pemeriksaan sumber independen dan cabang D=false atau q gagal tidak dibuktikan dari rekaman ini. Hasil tidak mengukur benar/salahnya ancaman, manfaat keputusan atau reliabilitas end-to-end. Dua skenario bukan 92 kasus independen.

Reproduksi: python audit_table4.py kasus_46_RESTRICTED.zip hasil_agregat.json. Script butuh Python 3.11+ dan pustaka standar. Output hanya agregat tanpa log mentah atau detail per kasus.
