#!/usr/bin/env python3
"""Audit cocok status Table 4 terhadap hasil pilot yang tersimpan; bukan uji implementasi penuh.
python audit_table4.py kasus_46_RESTRICTED.zip hasil_agregat.json
"""
import csv,hashlib,io,json,math,sys,zipfile
from collections import Counter
from pathlib import Path
archive,out=map(Path,sys.argv[1:]);
with zipfile.ZipFile(archive) as z:
 with z.open('hasil/kasus_pseudonim_RESTRICTED.csv') as raw: rows=list(csv.DictReader(io.TextIOWrapper(raw,encoding='utf-8-sig',newline='')))
assert len(rows)==46 and len({r['case_id'] for r in rows})==46
def flag(v):
 assert v in ('True','False'),f'Boolean tak dikenal {v!r}'
 return v=='True'
def valid(v): return math.isfinite(v) and 0<=v<=1
def table4(a,h,D,X,Q):
 if not a:return 'no_alert'
 if h:return 'abstain'
 if not D and not X:return 'abstain'
 if D and X and Q:return 'accept'
 return 'warn'
counts=Counter();actual=Counter();sim=Counter();pairs=Counter();constraints=Counter();status=Counter()
for r in rows:
 p,theta,q,x=map(float,(r['p_calibrated'],r['detector_threshold'],r['q_numeric_nonmissing_11'],r['x']))
 assert valid(p) and valid(theta) and theta<1 and valid(q) and valid(x)
 assert flag(r['source_verified']) is False
 a=p>=theta;D=(p-theta)/(1-theta)>=.5;X=x>=.7;Q=q>=.9
 assert D==flag(r['passes_margin_illustrative']) and X==flag(r['passes_x_illustrative']) and Q==flag(r['passes_q_illustrative'])
 # Mode 1: unverified provenance maps to H=1. This is an explicit audit mapping.
 a1=table4(a,True,D,X,False)
 # Mode 2: counterfactual only: source passes and all critical inputs assumed present.
 a2=table4(a,False,D,X,Q)
 b1=r['source_unverified_decision'];b2=r['assumed_source_with_m3'];base=r['assumed_source_baseline']
 actual[(a1,b1)]+=1;sim[(a2,b2)]+=1;pairs[(base,b2)]+=1
 counts.update({'total':1,'candidate':int(a),'D_pass':int(D),'X_pass':int(X),'Q_numeric_pass':int(Q),'source_verified':int(flag(r['source_verified']))})
 status[r['m3_status']]+=1;constraints[(D,X,Q)]+=1
assert sum(actual.values())==sum(sim.values())==46
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def unpack(c,names):return [dict(zip(names,k),count=v) for k,v in sorted(c.items(),key=lambda x:str(x[0]))]
data={'sha256_input_zip':digest(archive),'status':'POST_HOC_STATUS_COMPARISON_NOT_FULL_IMPLEMENTATION','assumptions':{'thresholds_from_recorded_pilot':{'tau_d':.5,'tau_x':.7,'tau_q':.9},'a':'p >= detector_threshold; 46 archived candidates only','source_unverified':'pi=0 -> H=1 as audit mapping','source_assumed_valid':'pi=1 and H=0 imposed counterfactually; no proof all critical fields present','q':'numeric non-missing proxy, not verified original-feature completeness'},'counts':dict(counts),'m3_status':dict(status),'input_combinations_D_X_Q':unpack(constraints,['D','X','Q_numeric']),'table4_vs_stored_unverified':unpack(actual,['table4_out','stored_pilot_out']),'table4_vs_stored_assumed_valid':unpack(sim,['table4_out','stored_pilot_out']),'baseline_vs_with_m3_assumed_valid':unpack(pairs,['baseline','with_m3']),'limitations':['Retrospective status comparison; table-derived calculator is new and no new implementation was run on the model or raw logs.','Binary decision outputs only; reason codes, source ID, observation unit, full feature availability and real provenance not verified.','Cases all candidates; D and q proxy show no failure in these records; no_alert and many branches not covered.','Source true and no critical absence are assumptions, not measured facts.','No independent incident labels; no validity, full reliability or evidence of reduced false alerts.','Does not replace constructed-case verification or new confirmatory evaluation.']}
out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(data,ensure_ascii=False,indent=2))
